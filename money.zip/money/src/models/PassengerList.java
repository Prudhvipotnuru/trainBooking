package models;

import java.util.ArrayList;

public class PassengerList extends ArrayList<Passenger> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
