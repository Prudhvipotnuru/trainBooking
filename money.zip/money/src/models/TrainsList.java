package models;

import java.util.ArrayList;

public class TrainsList extends ArrayList<Train> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
