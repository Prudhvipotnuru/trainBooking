package models;

import java.util.ArrayList;

public class StationsList extends ArrayList<Station> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
